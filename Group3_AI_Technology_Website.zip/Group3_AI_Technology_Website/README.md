# Group3 AI Technology Website

## How to run
1. Extract this ZIP file.
2. Open `index.html` in a modern web browser.
3. The page uses HTML and CSS only. No build tools or JavaScript are required.

## Notes
- The page is responsive for desktop, tablet, and mobile screens.
- Images are loaded from Unsplash over the internet, so an internet connection is needed to display them.
- Replace the sample names, email addresses, marks, dates, and project details with your own information before submission.
